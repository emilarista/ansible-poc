# Ansible & CloudVision examples

**WARNING**: a dedicated repository at [arista-netdevops-community/ansible-cvp-toi](https://github.com/arista-netdevops-community/ansible-cvp-toi) is available with example for every ansible-cvp module.
